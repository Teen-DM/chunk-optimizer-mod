package com.example.chunkoptimizer;

import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

public class ChunkLoadOptimizer {
    private static final Logger LOGGER = LogManager.getLogger();
    private static ExecutorService chunkLoaderExecutor;
    private static LinkedBlockingQueue<ChunkLoadTask> chunkLoadQueue;
    private static int maxConcurrentLoads = Config.MAX_CONCURRENT_LOADS.get();
    private static int queueSizeLimit = Config.QUEUE_SIZE_LIMIT.get();
    private static long lastProcessTime = 0;
    private static long processInterval = Config.PROCESS_INTERVAL.get();

    public static void initialize() {
        reloadConfig();
        chunkLoaderExecutor = Executors.newFixedThreadPool(maxConcurrentLoads);
        chunkLoadQueue = new LinkedBlockingQueue<>(queueSizeLimit);
        LOGGER.info("Chunk Load Optimizer initialized with {} concurrent loaders", maxConcurrentLoads);
    }

    public static void reloadConfig() {
        maxConcurrentLoads = Config.MAX_CONCURRENT_LOADS.get();
        queueSizeLimit = Config.QUEUE_SIZE_LIMIT.get();
        processInterval = Config.PROCESS_INTERVAL.get();
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            processChunkLoadQueue();
        }
    }

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (event.getLevel() instanceof ServerLevel) {
            ServerLevel level = (ServerLevel) event.getLevel();
            ChunkAccess chunk = event.getChunk();
            
            // Schedule async processing for newly loaded chunks
            if (chunkLoadQueue.size() < queueSizeLimit) {
                chunkLoadQueue.offer(new ChunkLoadTask(level, chunk.getPos()));
            }
        }
    }

    private static void processChunkLoadQueue() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastProcessTime < processInterval) {
            return;
        }

        lastProcessTime = currentTime;
        
        // Process up to maxConcurrentLoads chunks per tick to spread load
        for (int i = 0; i < maxConcurrentLoads && !chunkLoadQueue.isEmpty(); i++) {
            ChunkLoadTask task = chunkLoadQueue.poll();
            if (task != null) {
                CompletableFuture.runAsync(() -> {
                    try {
                        optimizeChunkLoading(task.level, task.chunkPos);
                    } catch (Exception e) {
                        LOGGER.warn("Failed to optimize chunk at {}", task.chunkPos, e);
                    }
                }, chunkLoaderExecutor);
            }
        }
    }

    private static void optimizeChunkLoading(ServerLevel level, ChunkPos chunkPos) {
        // Implement chunk pre-loading and optimization logic
        // This runs in background thread to reduce main thread load
        
        try {
            // Pre-load neighboring chunks to prevent cascading loads
            if (Config.PRELOAD_NEIGHBORS.get()) {
                for (int x = -1; x <= 1; x++) {
                    for (int z = -1; z <= 1; z++) {
                        if (x == 0 && z == 0) continue;
                        
                        ChunkPos neighborPos = new ChunkPos(chunkPos.x + x, chunkPos.z + z);
                        if (!level.getChunkSource().hasChunk(neighborPos.x, neighborPos.z)) {
                            // Schedule neighbor chunk for background loading
                            level.getChunkSource().getChunk(neighborPos.x, neighborPos.z, ChunkStatus.FULL, false);
                        }
                    }
                }
            }
            
            // Optimize chunk data access patterns
            optimizeChunkDataAccess(level, chunkPos);
            
        } catch (Exception e) {
            LOGGER.debug("Background chunk optimization failed for {}", chunkPos, e);
        }
    }

    private static void optimizeChunkDataAccess(ServerLevel level, ChunkPos chunkPos) {
        // Implement data access optimization to reduce lag spikes
        // This could include pre-caching frequently accessed data
        // or optimizing chunk data structures
        if (Config.ENABLE_DATA_CACHING.get()) {
            // Add data caching logic here
            LOGGER.debug("Optimizing data access for chunk at {}", chunkPos);
        }
    }

    private static class ChunkLoadTask {
        public final ServerLevel level;
        public final ChunkPos chunkPos;

        public ChunkLoadTask(ServerLevel level, ChunkPos chunkPos) {
            this.level = level;
            this.chunkPos = chunkPos;
        }
    }

    public static void shutdown() {
        if (chunkLoaderExecutor != null) {
            chunkLoaderExecutor.shutdown();
        }
    }
}